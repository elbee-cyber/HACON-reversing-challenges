#include <string.h>
#include <stdio.h>

int main(int argc, char *argv[]){
	if(argc==2){
		printf("=Chopdown Logic Bomb v.1=\n");
		printf("Authenticating user..\n");
		if((char)argv[1][0] == 'h'){
			if((char)argv[1][1] == 'a'){
				if((char)argv[1][2] == 'c'){
					if((char)argv[1][3] == '{'){
						if((char)argv[1][4] == 'b'){
							if((char)argv[1][5] == '1'){
								if((char)argv[1][6] == 't'){
									if((char)argv[1][7] == '_'){
										if((char)argv[1][8] == 'b'){
											if((char)argv[1][9] == 'y'){
												if((char)argv[1][10] == '_'){
													if((char)argv[1][11] == 'b'){
														if((char)argv[1][12] == '1'){
															if((char)argv[1][13] == 't'){
																if((char)argv[1][14] == '}'){
																	printf("Correct flag!\n");
                                                                    printf("Welcome Admin.\n");
																	return 0;



	}}}}}}}}}}}}}}}
	}else{
		printf("Usuage: ./chopdown '<flag>'\n");
		return 0;
	}
	
	printf("Authentication FAILURE!\n");
	return 0;

}