
## Compiled from python with pyinstaller

The ransomware is uncrackable! Don't even try!
**ATTENTION ALL WRITERS: DON'T VIEW THE KILLSWITCH**

The ransomware was originally written in python and compiled using pyinstaller.
Good luck getting to the bottom of this =)

(NOTE: The binary in dist is not actual ransomware. It will not harm your machine in any way. It is only printing output to the screen and is completley safe to run.)


